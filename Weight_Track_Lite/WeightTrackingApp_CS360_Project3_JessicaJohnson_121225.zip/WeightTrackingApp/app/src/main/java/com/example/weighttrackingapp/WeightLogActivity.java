/**
 * WeightTrack Lite
 * WeightLogActivity.java
 * Weight Log Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Displays saved weight entries using a RecyclerView.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Loads weight entries from SharedPreferences
 * - Deletes entries and updates saved data
 * - Navigation to Add Weight and Dashboard screens
 */

package com.example.weighttrackingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class WeightLogActivity extends AppCompatActivity {

    // Keys for SharedPreferences to store/retrieve weight entries
    private static final String PREFS_NAME = "WeightPrefs";
    private static final String KEY_ENTRY_COUNT = "entryCount";
    private static final String KEY_ENTRY_PREFIX = "entry_";
    private static final String KEY_DATE_SUFFIX = "_date";
    private static final String KEY_WEIGHT_SUFFIX = "_weight";

    private RecyclerView recyclerView;
    private WeightLogAdapter adapter;
    private ArrayList<WeightEntry> entryList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weight_log);

        // Status bar / navigation bar
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // RecycyclerView displays entries
        recyclerView = findViewById(R.id.recyclerWeightLog);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Adapter with delete callback
        adapter = new WeightLogAdapter(entryList, this::onDeleteEntry);
        recyclerView.setAdapter(adapter);

        // Button: Log Weight
        Button buttonLogWeight = findViewById(R.id.buttonLogWeight);
        buttonLogWeight.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        // Button: Dashboard
        Button buttonHome = findViewById(R.id.buttonHome);
        buttonHome.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogActivity.this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        // Load any saved entries
        loadEntriesFromPrefs();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload in case user added a new weight and came back
        loadEntriesFromPrefs();
    }


    // Read all saved entries from SharedPreferences and update the list + adapter.
    // Entries are stored using an index based key pattern (entry_0_date, entry_0_weight)

    private void loadEntriesFromPrefs() {
        entryList.clear();

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int entryCount = prefs.getInt(KEY_ENTRY_COUNT, 0);

        for (int i = 0; i < entryCount; i++) {
            String date = prefs.getString(
                    KEY_ENTRY_PREFIX + i + KEY_DATE_SUFFIX,
                    null
            );
            float weight = prefs.getFloat(
                    KEY_ENTRY_PREFIX + i + KEY_WEIGHT_SUFFIX,
                    0f
            );

            // Only add valid entries
            if (date != null && weight != 0f) {
                entryList.add(new WeightEntry(date, weight));
            }
        }

        adapter.notifyDataSetChanged();
    }

    // User Taps Delete on a row
    // Removes entry from the list and updates SharedPreferences
    private void onDeleteEntry(WeightEntry entry) {
        // Remove from list
        int index = entryList.indexOf(entry);
        if (index == -1) {
            return;
        }
        entryList.remove(index);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        // Clear any existing entries
        int oldCount = prefs.getInt(KEY_ENTRY_COUNT, 0);
        for (int i = 0; i < oldCount; i++) {
            editor.remove(KEY_ENTRY_PREFIX + i + KEY_DATE_SUFFIX);
            editor.remove(KEY_ENTRY_PREFIX + i + KEY_WEIGHT_SUFFIX);
        }

        // Save the new list
        editor.putInt(KEY_ENTRY_COUNT, entryList.size());
        for (int i = 0; i < entryList.size(); i++) {
            WeightEntry e = entryList.get(i);
            editor.putString(
                    KEY_ENTRY_PREFIX + i + KEY_DATE_SUFFIX,
                    e.getDate()
            );
            editor.putFloat(
                    KEY_ENTRY_PREFIX + i + KEY_WEIGHT_SUFFIX,
                    e.getWeight()
            );
        }

        editor.apply();

        // Tell the adapter/user that one item was removed
        adapter.notifyItemRemoved(index);
        Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
    }
}
