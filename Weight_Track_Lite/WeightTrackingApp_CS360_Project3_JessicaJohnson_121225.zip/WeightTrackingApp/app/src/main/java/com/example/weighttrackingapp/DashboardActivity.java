/**
 * WeightTrack Lite
 * DashboardActivity.java
 * Main Dashboard Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Displays progress values such as current weight, goal weight, and remaining progress.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Loads current weight and goal weight from SharedPreferences
 * - Calculates pounds remaining and percent toward goal
 * - Updates a progress bar and provides navigation to app features
 */

package com.example.weighttrackingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    // Dashboard display values
    private TextView textCurrentWeightValue;
    private TextView textGoalWeightValue;
    private TextView textPoundsToGoalValue;
    private TextView textPercentToGoalValue;
    // Progress bar towards goal weight
    private ProgressBar progressBarToGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Connect UI to Variables
        textCurrentWeightValue = findViewById(R.id.textCurrentWeightValue);
        textGoalWeightValue = findViewById(R.id.textGoalWeightValue);
        textPoundsToGoalValue = findViewById(R.id.textPoundsToGoalValue);
        textPercentToGoalValue = findViewById(R.id.textPercentToGoalValue);
        progressBarToGoal = findViewById(R.id.progressBarToGoal);

        // When clicked, open AddWeightActivity to log today's weight
        Button buttonLogToday = findViewById(R.id.buttonLogToday);
        buttonLogToday.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        // When clicked, Go to ChangeGoalActivity to update the user's goal weight
        Button buttonChangeGoal = findViewById(R.id.buttonChangeGoal);
        buttonChangeGoal.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ChangeGoalActivity.class);
            startActivity(intent);
        });

        // When clicked, View weight history in WeightLogActivity
        Button buttonViewLog = findViewById(R.id.buttonViewLog);
        buttonViewLog.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, WeightLogActivity.class);
            startActivity(intent);
        });

        // When clicked, open SMS settings
        Button buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, SmsSettingActivity.class);
            startActivity(intent);
        });

        // When clicked, logout
        Button buttonLogout = findViewById(R.id.buttonLogout);
        buttonLogout.setOnClickListener(v -> {
            Toast.makeText(DashboardActivity.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();  // Prevent going "back" into Dashboard
        });


        // Load saved values
        updateDashboard();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update dashboard values when returning from a different screen
        updateDashboard();
    }
    /* Pulls the saved current weight and goal weight from SharedPreferences
        and updates the dashboard values.
        Calculates pounds remaining for goal, percentage left of the goal, progress bar
     */
    private void updateDashboard() {
        // Load saved values
        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        float currentWeight = prefs.getFloat("currentWeight", 0f);
        float goalWeight = prefs.getFloat("goalWeight", 0f);

        // Show -- if no values are saved yet
        textCurrentWeightValue.setText(
                currentWeight == 0f ? "-- lbs" : currentWeight + " lbs"
        );
        textGoalWeightValue.setText(
                goalWeight == 0f ? "-- lbs" : goalWeight + " lbs"
        );

        // Only calculate if both values exist
        if (goalWeight > 0f && currentWeight > 0f) {
            // Pounds between current and Goal Weight
            float poundsDiff = Math.abs(goalWeight - currentWeight);

            // Percentage of goal met
            float percentDiff = (poundsDiff / goalWeight) * 100f;

            // Percentage max is 100%
            if (percentDiff > 100f) {
                percentDiff = 100f;
            }

            textPoundsToGoalValue.setText(String.format("%.1f lbs", poundsDiff));
            textPercentToGoalValue.setText(String.format("%.1f %%", percentDiff));
            progressBarToGoal.setProgress((int) percentDiff);

            // Show -- placeholders if no data exists yet
        } else {
            textPoundsToGoalValue.setText("-- lbs");
            textPercentToGoalValue.setText("-- %");
            progressBarToGoal.setProgress(0);
        }


    }
}
