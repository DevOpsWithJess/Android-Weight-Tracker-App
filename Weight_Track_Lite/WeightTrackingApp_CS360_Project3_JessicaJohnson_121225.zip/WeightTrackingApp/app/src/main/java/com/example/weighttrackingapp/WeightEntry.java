/**
 * WeightTrack Lite
 * WeightEntry.java
 * RecyclerView Data Model
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Simple data model representing a single weight log entry.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Stores date and weight values for RecyclerView display
 * - Serializable for data handling
 */

package com.example.weighttrackingapp;

import java.io.Serializable;

public class WeightEntry implements Serializable {
    private String date; // MM/DD/YYYY
    private float weight; // Weight in Whole number or decimal

    // Constructor that creates a new WeightEntry
    public WeightEntry(String date, float weight) {
        this.date = date;
        this.weight = weight;
    }

    public String getDate() { return date; } // Getter for the date

    public float getWeight() { return weight; } // Getter for the weight

    // Set a new date
    public void setDate(String date) {
        this.date = date;
    }

    // Set a new weight
    public void setWeight(float weight) {
        this.weight = weight;
    }

    // Output for debugging
    @Override
    public String toString() {
        return date + "-" + weight + " lbs";
    }
}
